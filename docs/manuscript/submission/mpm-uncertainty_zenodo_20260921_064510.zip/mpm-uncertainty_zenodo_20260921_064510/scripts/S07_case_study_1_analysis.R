# S07: analyse analysis 1 results and create figures.

# libraries ----
source("code/setup.R")
setup_packages(c(
  "tidyverse", "popbio", "popdemo", "Rcompadre", "Rage",
  "ggridges", "gridExtra", "patchwork",
  "rstan", "loo", "viridisLite"
))
setup_rstan()
source("code/functions.R")
# Plot style helpers (theme_mpm(), mpm_colors()) from code/functions.R
set_mpm_plot_defaults()
seed <- 5654
set.seed(seed)
cols <- mpm_colors()


# set options for rstan library ----
# handled in setup_rstan()


# load compadre data ----
compadre <- load_compadre(corrected = TRUE)


# load sampling distributions ----
load(file = "data/derived/analysis_cache/full_pt_shape.RData")
load(file = "data/derived/analysis_cache/full_pt_other.RData")

load(file = "data/derived/analysis_cache/full_sd_shape.RData")
load(file = "data/derived/analysis_cache/full_sd_other.RData")


# plot sampling distributions vs. point estimate for shape and l0 ----
tt <- theme_mpm() +
  theme(
    axis.title = element_text(size = 12.5),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    panel.border = element_rect(linewidth = 0.5, fill = NA),
    plot.margin = margin(2, 2, 2, 2)
  )

p1 <- ggplot(sd_shape_out, aes(y = id_S)) +
  geom_vline(xintercept = 0, color = "grey70", alpha = 0.6, linewidth = 0.2, linetype = 2) +
  geom_density_ridges(aes(x = S),
    rel_min_height = 1e-2,
    scale = 3, fill = cols$sampling_fill, alpha = 0.4, color = NA, linewidth = 0
  ) +
  geom_point(data = pt_shape_out, aes(x = S_pt), size = 0.9, shape = 16, color = cols$point) +
  annotate("text", x = Inf, y = 2.6, label = "A", vjust = 1.5, size = 5, fontface = "bold") +
  coord_flip(xlim = c(-0.3, 0.2)) +
  labs(
    y = expression(paste("Population (ranked by ", italic(S), ")")),
    x = expression(paste("Mortality trajectory shape (", italic(S), ")"))
  ) +
  tt

p2 <- ggplot(sd_shape_out, aes(y = id_L)) +
  geom_density_ridges(aes(x = L),
    rel_min_height = 1e-2,
    scale = 3, fill = cols$sampling_fill, alpha = 0.4, color = NA, linewidth = 0
  ) +
  geom_point(data = pt_shape_out, aes(x = L_pt), size = 0.9, shape = 16, color = cols$point) +
  annotate("text", x = Inf, y = 2.6, label = "B", vjust = 1.5, size = 5, fontface = "bold") +
  scale_x_log10(limits = c(1.2, 1500)) +
  coord_flip() +
  labs(
    y = expression(paste("Population (ranked by ", italic(L), ")")),
    x = expression(paste("Mature life expectancy (", italic(L), ")"))
  ) +
  tt

# arrange plot panels
g <- patchwork::wrap_plots(p1, p2, ncol = 1) +
  patchwork::plot_annotation(theme = theme(plot.margin = margin(2, 2, 2, 2)))

if (!dir.exists("figures")) dir.create("figures", recursive = TRUE)
ggsave("figures/Figure_3_analysis1_point_vs_sampling_distributions.png", g, height = 123, width = 90, units = "mm", dpi = 300)


# plot sampling distributions vs. point estimate for other parameters ----
tt <- theme_mpm() +
  theme(
    axis.title = element_text(size = 10),
    axis.text.x = element_blank(),
    axis.text.y = element_text(size = 8.5, angle = 90, hjust = 0.5),
    axis.ticks.x = element_blank(),
    panel.border = element_rect(linewidth = 0.5, fill = NA),
    plot.margin = margin(2, 2, 2, 2)
  )

pt_size <- 0.7
pt_shp <- 19
rdg_scale <- 7
rdg_size <- 0.2

p1 <- ggplot(sd_other_out, aes(y = id_loglam)) +
  geom_vline(xintercept = 0, alpha = 0.3) +
  geom_density_ridges(aes(x = loglam),
    rel_min_height = 0.01,
    scale = rdg_scale, fill = cols$fill, linewidth = rdg_size
  ) +
  geom_point(data = pt_other_out, aes(x = loglam_pt), size = pt_size, shape = pt_shp) +
  annotate("text", x = Inf, y = 4, label = "A", vjust = 1.5, size = 4, fontface = "bold") +
  scale_x_continuous(breaks = seq(-0.4, 0.6, 0.2)) +
  coord_flip(xlim = c(-0.4, 0.7)) +
  labs(
    y = expression(paste("Population (ranked by ", log ~ italic(lambda), ")")),
    x = expression(paste("Population growth (", log ~ italic(lambda), ")"))
  ) +
  tt

p2 <- ggplot(sd_other_out, aes(y = id_damp)) +
  geom_density_ridges(aes(x = damp),
    rel_min_height = 0.01,
    scale = rdg_scale, fill = cols$fill, linewidth = 0.3
  ) +
  geom_point(data = pt_other_out, aes(x = damp_pt), size = pt_size, shape = pt_shp) +
  annotate("text", x = Inf, y = 4, label = "B", vjust = 1.5, size = 4, fontface = "bold") +
  scale_x_log10() +
  coord_flip() +
  labs(
    y = expression(paste("Population (ranked by ", italic(rho), ")")),
    x = expression(paste("Damping ratio (", italic(rho), ")"))
  ) +
  tt

p3 <- ggplot(sd_other_out, aes(y = id_pmature)) +
  geom_density_ridges(aes(x = pmature),
    rel_min_height = 0.01,
    scale = rdg_scale, fill = cols$fill, linewidth = rdg_size
  ) +
  geom_point(data = pt_other_out, aes(x = pmature_pt), size = pt_size, shape = pt_shp) +
  annotate("text", x = Inf, y = 4, label = "C", vjust = 1.5, size = 4, fontface = "bold") +
  coord_flip() +
  scale_x_continuous(breaks = seq(0, 1, 0.2)) +
  labs(
    y = expression(paste("Population (ranked by Pr[Maturity])")),
    x = expression(paste("Pr[Maturity]"))
  ) +
  tt

p4 <- ggplot(sd_other_out, aes(y = id_gen)) +
  geom_density_ridges(aes(x = gen),
    rel_min_height = 0.01,
    scale = rdg_scale, fill = cols$fill, linewidth = rdg_size
  ) +
  geom_point(data = pt_other_out, aes(x = gen_pt), size = pt_size, shape = pt_shp) +
  annotate("text", x = Inf, y = 4, label = "D", vjust = 1.5, size = 4, fontface = "bold") +
  scale_x_log10() +
  coord_flip() +
  labs(
    y = expression(paste("Population (ranked by ", italic("T"), ")")),
    x = expression(paste("Generation time (", italic("T"), ")"))
  ) +
  tt

g1 <- patchwork::wrap_plots(p1, p2, p3, ncol = 1)
g2 <- patchwork::wrap_plots(p4, ncol = 1)
g <- patchwork::wrap_plots(g1, g2, ncol = 2)

ggsave("figures/Analysis1_additional_parameter_distributions.png", g, height = 7.5, width = 7.5, units = "in", dpi = 300)


# prep df for shape vs. pace analysis ----
df_shape <- sd_shape_out %>%
  mutate(log_L = log10(L)) %>%
  group_by(SpeciesAuthor, MatrixPopulation) %>%
  summarize(
    S_med = quantile(S, 0.500),
    S_mean = mean(S),
    S_se = sd(S),
    S_low = quantile(S, 0.025),
    S_upp = quantile(S, 0.975),
    L_med = quantile(L, 0.500),
    L_mean = mean(L),
    L_se = sd(L),
    log_L_med = quantile(log_L, 0.500),
    log_L_mean = mean(log_L),
    log_L_se = sd(log_L),
    L_low = quantile(L, 0.025),
    L_upp = quantile(L, 0.975),
    log_L_low = quantile(log_L, 0.025),
    log_L_upp = quantile(log_L, 0.975)
  ) %>%
  ungroup() %>%
  left_join(pt_shape_out) %>%
  mutate(
    spp_int = as.integer(as.factor(SpeciesAuthor)),
    id_shape = paste(SpeciesAuthor, MatrixPopulation, sep = " | ")
  ) %>%
  mutate(
    l0_pt = L_pt,
    l0_med = L_med,
    l0_mean = L_mean,
    l0_se = L_se,
    l0_low = L_low,
    l0_upp = L_upp,
    log_l0_med = log_L_med,
    log_l0_mean = log_L_mean,
    log_l0_se = log_L_se,
    log_l0_low = log_L_low,
    log_l0_upp = log_L_upp,
    shape_pt = S_pt,
    shape_med = S_med,
    shape_mean = S_mean,
    shape_se = S_se,
    shape_low = S_low,
    shape_upp = S_upp
  ) %>%
  mutate(across(where(is.numeric), ~ signif(.x, 3)))

if (!dir.exists("data/derived/analysis_cache")) {
  dir.create("data/derived/analysis_cache",
    recursive = TRUE
  )
}
write_csv(df_shape, "data/derived/analysis_cache/case1_shape_summary.csv")


# plot pace vs. shape, point estimates vs posterior means ----
p_pace_shape <- ggplot(df_shape) +
  geom_segment(aes(x = L_pt, y = S_pt, xend = L_mean, yend = S_mean),
    linewidth = 0.3, arrow = arrow(length = unit(0.02, "npc"))
  ) +
  geom_point(aes(L_pt, S_pt)) +
  scale_x_log10()

if (!dir.exists("figures")) dir.create("figures", recursive = TRUE)
ggsave("figures/Analysis1_pace_shape_scatter.png", p_pace_shape, height = 4, width = 4.5, units = "in", dpi = 300)


# model relationship between l0 and shape, assuming no sampling uncertainty ----

# compile stan models
stan_regress_hier <- stan_model("models/regress2.stan")
stan_regress_hier_error <- stan_model("models/regress_hier_error.stan")

# arrange data for stan
x_cent <- mean(log10(df_shape$l0_pt))
dat_stan <- list(
  N = nrow(df_shape),
  N_spp = length(unique(df_shape$SpeciesAuthor)),
  spp = df_shape$spp_int,
  x = log10(df_shape$l0_pt) - x_cent,
  y = df_shape$shape_pt
)

# fit stan model
stan_fit <- sampling(
  stan_regress_hier,
  data = dat_stan,
  warmup = 2000,
  iter = 4000,
  thin = 2,
  chains = 2,
  seed = seed
)

# model diagnostics

# extract posterior samples for intercept and slope
mu_alpha <- rstan_extract(stan_fit, "mu_alpha")
mu_beta <- rstan_extract(stan_fit, "mu_beta")

# extract posterior samples for best fit line and 95% credible interval
pred_x <- seq(min(dat_stan$x), max(dat_stan$x), length.out = 50)

pred_reg <- tibble(mu_alpha, mu_beta, pred_x = list(pred_x)) %>%
  mutate(pred = pmap(list(mu_alpha, mu_beta, pred_x), ~ ..1 + ..2 * ..3)) %>%
  dplyr::select(pred_x, pred) %>%
  unnest(cols = c(pred_x, pred)) %>%
  mutate(pred_x = 10^(pred_x + x_cent)) %>%
  group_by(pred_x) %>%
  summarize(
    pred_med = quantile(pred, 0.500),
    pred_low = quantile(pred, 0.025),
    pred_upp = quantile(pred, 0.975)
  )


# Model relationship between l0 and shape, with sampling uncertainty ----
# arrange data for stan
x_cent_error <- mean(df_shape$log_l0_mean)
dat_stan <- list(
  N = nrow(df_shape),
  N_spp = length(unique(df_shape$spp_int)),
  spp = df_shape$spp_int,
  x_mean = df_shape$log_l0_mean - x_cent_error,
  x_se = pmax(df_shape$log_l0_se, 1e-6),
  y_mean = df_shape$shape_mean,
  y_se = pmax(df_shape$shape_se, 1e-6)
)

# fit stan model
stan_fit_error <- sampling(
  stan_regress_hier_error,
  data = dat_stan,
  warmup = 3000,
  iter = 4000,
  thin = 2,
  chains = 2,
  control = list(adapt_delta = 0.9, stepsize = 0.1, max_treedepth = 12),
  seed = seed
)


# model diagnostics

# posterior samples for intercept and slope
mu_alpha_error <- rstan_extract(stan_fit_error, "mu_alpha")
mu_beta_error <- rstan_extract(stan_fit_error, "mu_beta")

quantile(mu_beta, c(0.025, 0.500, 0.975))
quantile(mu_beta_error, c(0.025, 0.500, 0.975))

df_beta_error <- data.frame(mu_beta_error)
pred_x_error <- seq(
  min(log10(df_shape$l0_pt) - x_cent_error),
  max(log10(df_shape$l0_pt) - x_cent_error),
  length.out = 50
)

# posterior samples for best fit line and 95% credible interval
pred_error <- tibble(mu_alpha_error, mu_beta_error, pred_x = list(pred_x_error)) %>%
  mutate(pred = pmap(list(mu_alpha_error, mu_beta_error, pred_x), ~ ..1 + ..2 * ..3)) %>%
  dplyr::select(pred_x, pred) %>%
  unnest(cols = c(pred_x, pred)) %>%
  mutate(pred_x = 10^(pred_x + x_cent_error)) %>%
  group_by(pred_x) %>%
  summarize(
    pred_med = quantile(pred, 0.500),
    pred_low = quantile(pred, 0.025),
    pred_upp = quantile(pred, 0.975)
  )


# prepare plot data ----
# left panel
lev <- c("Model using point estimates", "Model with sampling uncertainty")

# fit line
pred_full <- rbind(
  mutate(pred_reg, model = lev[1]),
  mutate(pred_error, model = lev[2])
) %>% mutate(model = factor(model, levels = lev))

# points and error bars
bars_reg <- df_shape %>%
  select(
    SpeciesAuthor, MatrixPopulation,
    l0_pt, shape_pt,
    l0_low, l0_upp,
    shape_low, shape_upp
  ) %>%
  mutate(
    model = lev[1],
    l0_med = l0_pt, shape_med = shape_pt,
    l0_low = NA_real_, l0_upp = NA_real_,
    shape_low = NA_real_, shape_upp = NA_real_
  )

bars_err <- df_shape %>%
  select(
    SpeciesAuthor, MatrixPopulation,
    l0_med, l0_low, l0_upp,
    shape_med, shape_low, shape_upp
  ) %>%
  mutate(model = lev[2], l0_pt = NA_real_, shape_pt = NA_real_)

bars_full <- bind_rows(bars_reg, bars_err) %>%
  mutate(model = factor(model, levels = lev))

pt_ref <- bind_rows(
  df_shape %>% transmute(l0_pt, shape_pt, model = lev[1]),
  df_shape %>% transmute(l0_pt, shape_pt, model = lev[2])
) %>%
  mutate(model = factor(model, levels = lev))

df_alpha <- bind_rows(
  tibble(alpha = mu_alpha, model = lev[1]),
  tibble(alpha = mu_alpha_error, model = lev[2])
) %>% mutate(model = factor(model, levels = lev))

df_beta <- bind_rows(
  tibble(beta = mu_beta, model = lev[1]),
  tibble(beta = mu_beta_error, model = lev[2])
) %>% mutate(model = factor(model, levels = lev))


# plot ----
tt <- theme_mpm() +
  theme(
    text = element_text(size = 11.5),
    axis.ticks = element_line(linewidth = 0.4),
    legend.position = "none",
    plot.margin = margin(2, 2, 2, 2)
  )

p1 <- ggplot(pred_full) +
  # Solid points for the point-estimate model (panel A).
  geom_point(
    data = dplyr::filter(pt_ref, model == lev[1]),
    aes(x = l0_pt, y = shape_pt),
    shape = 16, size = 1.3, color = cols$point
  ) +
  # Faint overlay of point estimates in the uncertainty panel for comparison.
  geom_point(
    data = dplyr::filter(pt_ref, model == lev[2]),
    aes(x = l0_pt, y = shape_pt),
    shape = 16, size = 1.1, color = cols$point, alpha = 0.25
  ) +
  # Cross centers (plus symbols) and intervals for sampling-uncertainty model.
  geom_point(
    data = dplyr::filter(bars_full, model == lev[2]),
    aes(x = l0_med, y = shape_med),
    shape = 3, size = 1.3, stroke = 0.4, color = cols$sampling
  ) +
  geom_linerange(
    data = dplyr::filter(bars_full, model == lev[2]),
    aes(x = l0_med, ymin = shape_low, ymax = shape_upp),
    linewidth = 0.3, alpha = 0.6, color = cols$sampling
  ) +
  geom_errorbarh(
    data = dplyr::filter(bars_full, model == lev[2]),
    aes(y = shape_med, xmin = l0_low, xmax = l0_upp),
    linewidth = 0.3, alpha = 0.6, color = cols$sampling
  ) +
  geom_line(
    aes(x = pred_x, y = pred_med, color = model),
    linewidth = 0.8
  ) +
  geom_ribbon(
    aes(x = pred_x, ymin = pred_low, ymax = pred_upp, fill = model),
    alpha = 0.2
  ) +
  scale_x_log10() +
  scale_color_manual(values = c(
    "Model using point estimates" = cols$point,
    "Model with sampling uncertainty" = cols$sampling
  )) +
  scale_fill_manual(values = c(
    "Model using point estimates" = cols$point,
    "Model with sampling uncertainty" = cols$sampling
  )) +
  coord_cartesian(ylim = c(-0.3, 0.2)) +
  facet_wrap(~model, ncol = 1) +
  labs(
    x = expression(paste("Mature life expectancy (", italic(L), ")")),
    y = expression(paste("Shape of mortality trajectory (", italic(S), ")"))
  ) +
  tt +
  theme(panel.border = element_blank())

p2 <- ggplot(df_beta, aes(x = beta)) +
  geom_vline(xintercept = 0, linetype = 2, alpha = 1, color = "grey65") +
  geom_density(aes(fill = model), alpha = 0.4, linewidth = 0) +
  coord_cartesian(xlim = c(-0.07, 0.07)) +
  scale_fill_manual(values = c(
    "Model using point estimates" = cols$point,
    "Model with sampling uncertainty" = cols$sampling
  )) +
  facet_wrap(~model, ncol = 1) +
  labs(x = expression(paste("Slope coefficient (", italic(beta), ")")), y = "Posterior density") +
  tt +
  theme(panel.border = element_blank())

# combine both plots
p <- p1 + p2 +
  patchwork::plot_layout(ncol = 2, widths = c(1.08, 1)) +
  patchwork::plot_annotation(
    tag_levels = "A",
    theme = theme(plot.margin = margin(2, 2, 2, 2))
  )

ggsave("figures/Figure_4_analysis1_life_expectancy_shape_relationship.png", p, height = 89, width = 180, units = "mm", dpi = 300)


# posterior summary ----
median(mu_beta)
median(mu_beta_error)

var(mu_beta_error) / var(mu_beta)

length(mu_beta[mu_beta > 0]) / length(mu_beta)
length(mu_beta_error[mu_beta_error > 0]) / length(mu_beta_error)


# Variance components analysis ----
stan_varcomp <- stan_model("models/varcomp.stan")


df_other <- sd_other_out %>%
  group_by(SpeciesAuthor, MatrixPopulation) %>%
  summarize(
    loglam_mean = mean(loglam),
    loglam_se = sd(loglam),
    damp_mean = mean(log10(damp)),
    damp_se = sd(log10(damp)),
    gen_mean = mean(log10(gen)),
    gen_se = sd(log10(gen)),
    pmature_mean = mean(logit(pmature)),
    pmature_se = sd(logit(pmature))
  ) %>%
  ungroup() %>%
  left_join(pt_other_out) %>%
  mutate(id_other = paste(SpeciesAuthor, MatrixPopulation, sep = " | ")) %>%
  mutate(damp_pt = log10(damp_pt)) %>%
  mutate(gen_pt = log10(gen_pt)) %>%
  mutate(pmature_pt = logit(pmature_pt))


dat_stan <- list(
  N = nrow(df_shape),
  y_mean = df_shape$log_l0_mean,
  y_se = df_shape$log_l0_se,
  y_pt = log10(df_shape$l0_pt)
)

dat_stan <- list(
  N = nrow(df_shape),
  y_mean = df_shape$shape_mean,
  y_se = df_shape$shape_se,
  y_pt = df_shape$shape_pt
)

dat_stan <- list(
  N = nrow(df_other),
  y_mean = df_other$loglam_mean,
  y_se = df_other$loglam_se,
  y_pt = df_other$loglam_pt
)

dat_stan <- list(
  N = nrow(df_other),
  y_mean = df_other$damp_mean,
  y_se = df_other$damp_se,
  y_pt = df_other$damp_pt
)

dat_stan <- list(
  N = nrow(df_other),
  y_mean = df_other$gen_mean,
  y_se = df_other$gen_se,
  y_pt = df_other$gen_pt
)

dat_stan <- list(
  N = nrow(df_other),
  y_mean = df_other$pmature_mean,
  y_se = df_other$pmature_se,
  y_pt = df_other$pmature_pt
)

dat_stan$y_se <- pmax(dat_stan$y_se, 1e-6)

# fit stan model
stan_fit_varcomp <- sampling(
  stan_varcomp,
  data = dat_stan,
  warmup = 3000,
  iter = 4000,
  thin = 2,
  chains = 2,
  control = list(adapt_delta = 0.95, stepsize = 0.05, max_treedepth = 12),
  seed = seed
)

pvar_w <- rstan_extract(stan_fit_varcomp, "pvar_w")
quantile(pvar_w, c(0.025, 0.500, 0.975))


df_theta <- posterior_vec(stan_fit_varcomp, x = df_other$id_other, "theta") %>%
  mutate(x = fct_reorder(x, med)) %>%
  mutate(across(where(is.numeric), ~ signif(.x, 3)))

write_csv(df_other, "data/derived/analysis_cache/case1_other_summary.csv")

p_theta <- ggplot(df_theta, aes(x = x)) +
  geom_point(aes(y = med)) +
  geom_errorbar(aes(ymin = low95, ymax = upp95)) +
  coord_flip()

ggsave("figures/Analysis1_variance_components_scatter.png", p_theta, height = 4.5, width = 5.5, units = "in", dpi = 300)

beta_summary <- df_beta %>%
  group_by(model) %>%
  summarize(
    beta_med = quantile(beta, 0.500),
    beta_low = quantile(beta, 0.025),
    beta_upp = quantile(beta, 0.975),
    p_beta_gt0 = mean(beta > 0),
    .groups = "drop"
  )
beta_summary <- beta_summary %>%
  mutate(across(c(beta_med, beta_low, beta_upp), ~ signif(.x, 3)),
    p_beta_gt0 = round(p_beta_gt0, 3)
  )
write_csv(beta_summary, "data/derived/analysis_cache/case1_beta_summary.csv")


var_a_pt <- var(dat_stan$y_pt)
var_a <- rstan_extract(stan_fit_varcomp, "var_a")
quantile(var_a_pt / var_a, c(0.025, 0.500, 0.975))


var(df_shape$shape_pt) / var(df_shape$shape_mean)
var(log10(df_shape$l0_pt)) / var(df_shape$log_l0_mean)

var(df_other$loglam_pt) / var(df_other$loglam_mean)
var(df_other$damp_pt) / var(df_other$damp_mean)
var(df_other$gen_pt) / var(df_other$gen_mean)
