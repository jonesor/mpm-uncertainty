# Zenodo bundle manifest

- Bundle: `mpm-uncertainty_zenodo_20260919_183525`
- Created (UTC): 2026-09-19 16:35:25 UTC
- File count: 113

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
