# Zenodo bundle manifest

- Bundle: `mpm-uncertainty_zenodo_20260923_145621`
- Created (UTC): 2026-09-23 12:56:21 UTC
- File count: 113

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
