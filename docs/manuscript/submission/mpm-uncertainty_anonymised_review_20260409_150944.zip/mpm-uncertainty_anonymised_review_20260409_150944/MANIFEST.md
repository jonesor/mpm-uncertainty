# Anonymised review bundle manifest

- Bundle: `mpm-uncertainty_anonymised_review_20260409_150944`
- Created (UTC): 2026-04-09 13:09:44 UTC
- File count: 100

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
