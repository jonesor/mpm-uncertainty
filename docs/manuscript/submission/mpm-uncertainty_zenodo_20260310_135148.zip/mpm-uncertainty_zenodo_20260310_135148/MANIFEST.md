# Zenodo bundle manifest

- Bundle: `mpm-uncertainty_zenodo_20260310_135148`
- Created (UTC): 2026-03-10 12:51:48 UTC
- File count: 131

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
