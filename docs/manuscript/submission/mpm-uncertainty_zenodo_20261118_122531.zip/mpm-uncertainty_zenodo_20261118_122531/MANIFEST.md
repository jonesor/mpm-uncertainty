# Zenodo bundle manifest

- Bundle: `mpm-uncertainty_zenodo_20261118_122531`
- Created (UTC): 2026-11-18 11:25:32 UTC
- File count: 188

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
