data/derived/analysis_cache/
----------------------------
Intermediate analysis objects written by scripts and reused in later steps.
These are not final results; they are cached to speed reruns.

Typical contents
----------------
- `sd_*.RData`    Study-level sampling distribution objects.
- `sds_*.RData`   Species-level sampling distribution objects.
- `full_*.RData`  Aggregated summaries used by downstream analyses and figures.
