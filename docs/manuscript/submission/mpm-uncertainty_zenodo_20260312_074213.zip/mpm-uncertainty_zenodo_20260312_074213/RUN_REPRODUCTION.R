# Reproduce analyses and manuscripts from this Zenodo bundle ----
source('scripts/00_check_setup.R')
source('scripts/S01_compadre_correct.R')
source('scripts/S02_target_studies.R')
source('scripts/S03_sampling_distrib_single_mpm.R')
source('scripts/S04_case_study_1_studies.R')
source('scripts/S05_case_study_1_studies_spp.R')
source('scripts/S06_case_study_1_derived.R')
source('scripts/S07_case_study_1_analysis.R')
source('scripts/S08_case_study_1_analysis_spp.R')
source('scripts/S09_case_study_1_surv_issue.R')
source('scripts/S10_case_study_1_var_comp.R')
# Optional PRISM download/re-extraction step:
# source('scripts/S11_case_study_2_prism.R')
source('scripts/S12_case_study_2.R')
source('scripts/S13_supplement.R')
source('scripts/99_make_tables.R')
rmarkdown::render(
  'docs/manuscript/manuscript_main.Rmd',
  output_format = 'bookdown::word_document2',
  output_file = 'sampling_uncertainty_mpm_main.docx',
  quiet = TRUE
)
rmarkdown::render(
  'docs/manuscript/manuscript_supplement.Rmd',
  output_format = 'bookdown::word_document2',
  output_file = 'sampling_uncertainty_mpm_supplement.docx',
  quiet = TRUE
)
