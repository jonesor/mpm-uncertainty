# Zenodo bundle manifest

- Bundle: `mpm-uncertainty_zenodo_20260312_074213`
- Created (UTC): 2026-03-12 06:42:13 UTC
- File count: 112

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
