# Zenodo bundle manifest

- Bundle: `mpm-uncertainty_zenodo_20260409_134238`
- Created (UTC): 2026-04-09 11:42:38 UTC
- File count: 109

## Reproduction

From the bundle root, run:

```r
source('RUN_REPRODUCTION.R')
```

## Integrity

- `MANIFEST.csv` records path, file size, modification timestamp, and MD5 checksum for each file.
- Recompute checksums and compare to `MANIFEST.csv` before archiving/deposition.
